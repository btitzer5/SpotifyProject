using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SpotifyProject.Pages.Chatbot
{
    public class ChatbotModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
